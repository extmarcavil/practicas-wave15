# Proyecto Final - Bootcamp Wave 15 - Java
## Integrantes:

Barraza, Miguel Angel 

Fedele, Lucas

Leon, Jesus 

Ramirez, Thiago 

Salomone, Ana 

Sinnott Segura, Gonzalo

# Objetivo
El objetivo de este proyecto final es implementar una API REST aplicando los contenidos trabajados durante todo el BOOTCAMP MELI. (Git, Java, Spring, Bases de datos y calidad de software).

El desafío es crear los artefactos necesarios para permitir las siguientes funcionalidades:

- Poder ingresar un lote de productos a warehouse de fulfillment con el objetivo de registrar esa existencia en el stock.
- Tener la información necesaria para entender en qué sector debe almacenarse esa mercadería para que se mantenga en buen estado mientras se encuentre en el depósito y para que se le pueda mostrar al colaborador que va a ir a buscar el producto (picking) donde se encuentra.
- Poder detectar si hay productos que están por vencer para realizar alguna acción al respecto (puede ser devolverlos al Seller, tirarlos o realizar alguna acción comercial específica para liquidarlos).
- Poder consultar el stock, listar qué productos se encuentran en qué warehouse y dado un producto específico también entender en cual warehouse se encuentra almacenado.
- Poder registrar la orden de compra para que los colaboradores dentro del fullfilment puedan armar el/los pedidos para despacharlos.

# Diagrama de Clases y Diagrama Entidad - Relación:

<a href="https://imgur.com/SeaNHEF"><img src="https://i.imgur.com/SeaNHEF.jpg" /></a>



⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃
# 📁 Requerimiento 1:  ml-insert-batch-in-fulfillment-warehouse-01

COMO Representante del warehouse de fulfillment QUIERO ingresar un lote de productos a warehouse de fulfillment PARA registrar la existencia de stock.

## End-point: Req1 - 1

### Descripción: 

Dar de alta un lote con el stock de productos que la compone. 

Devolver el nuevo lote con status code “201 CREATED”.

### Method: POST
>```
>{{url-app}}/api/v1/fresh-products/inboundorder
>```
### Headers

|Content-Type|Value|
|---|---|
|X-Auth-Token|{{token-fury}}|


### Body (**raw**)

```json
{
  "inbound_order": {
    "order_number": 1,
    "order_date": "02-06-2022",
    "section": {
      "section_code": "1",
      "warehouse_code": "1"
    },
    "batch_stock": [
      {
        "batch_number": 1003,
        "product_id": "3",
        "current_temperature": 10,
        "minimum_temperature": 10,
        "initial_quantity": 16,
        "current_quantity": 16,
        "manufacturing_date": "01-06-2022",
        "manufacturing_time" : "01-06-2022 10:20:38",
        "due_date": "10-02-2023"
      }
    ]
  }
}
```


⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃

## End-point: Req1 - 2

### Descripción:

En el caso de que el lote ya exista  y deba actualizarse el mismo. 

Devolver el stock actualizado con status code “201 CREATED”.

### Method: PUT
>```
>{{url-app}}/api/v1/fresh-products/inboundorder
>```
### Headers

|Content-Type|Value|
|---|---|
|X-Auth-Token|{{token-fury}}|


### Body (**raw**)

```json
{
  "inbound_order": {
    "order_number": 1,
    "order_date": "02-06-2022",
    "section": {
      "section_code": "1",
      "warehouse_code": "1"
    },
    "batch_stock": [
      {
        "batch_number": 1003,
        "product_id": "3",
        "current_temperature": 10,
        "minimum_temperature": 10,
        "initial_quantity": 16,
        "current_quantity": 10,
        "manufacturing_date": "01-06-2022",
        "manufacturing_time":"01-06-2022 10:20:38",
        "due_date": "10-02-2022"
      }
    ]
  }
}
```


⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃
# 📁 Requerimiento 2:  ml-add-products-to-cart-01

COMO buyer QUIERO agregar productos al carrito de compras del Marketplace PARA comprarlos si lo deseo

## End-point: Req2 - 1

## Descripción:

Ver una lista de productos completa.

Si la lista no existe, debe devolver un “404 Not Found”.


### Method: GET
>```
>{{url-app}}/api/v1/fresh-products/list
>```
### Headers

|Content-Type|Value|
|---|---|
|X-Auth-Token|{{token-fury}}|


### Body (**raw**)

⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃

## End-point: Req2 - 2

## Descripción:

Ver una lista de productos según categoría:
- FS=Fresco
- RF=Refrigerado
- FF=Congelado

Si la lista no existe, debe devolver un “404 Not Found”.

### Method: GET
>```
>{{url-app}}/api/v1/fresh-products/list?category=FS
>```
### Headers

|Content-Type|Value|
|---|---|
|X-Auth-Token|{{token-fury}}|


### Query Params

|Param|value|
|---|---|
|category|FS|
|category|RF|
|category|FF|



⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃

## End-point: Req2 - 3

## Descripción:

Dar de alta una orden con la lista de productos que componen la PurchaseOrder.

Calcular el precio final,  y devolverlo junto a un status code “201 CREATED”.

Si no hay stock de un producto notificar la situación devolviendo un error por producto, no a nivel de orden.

### Method: POST
>```
>{{url-app}}/api/v1/fresh-products/orders
>```
### Headers

|Content-Type|Value|
|---|---|
|X-Auth-Token|{{token-fury}}|


### Body (**raw**)

```json
{
  "inbound_order": {
    "order_number": 1,
    "order_date": "02-06-2022",
    "section": {
      "section_code": "1",
      "warehouse_code": "1"
    },
    "batch_stock": [
      {
        "batch_number": 1003,
        "product_id": "3",
        "current_temperature": 10,
        "minimum_temperature": 10,
        "initial_quantity": 16,
        "current_quantity": 10,
        "manufacturing_date": "01-06-2022",
        "manufacturing_time":"01-06-2022 10:20:38",
        "due_date": "10-02-2022"
      }
    ]
  }
}
```

# 📁 Requerimiento 5: ml-check-batch-stock-due-date-01

COMO Representante QUIERO poder consultar los productos en stock próximos a vencer en un determinado warehouse PARA poder aplicar alguna acción comercial con los mismos.

## End-point: Req5 - 1

## Descripción:

Obtener todos los lotes próximos a vencer entre hoy y la cantidad de días posteriores ordenados por fecha de vencimiento.

### Method: GET
>```
>{{url-app}}/api/v1/fresh-products/batch/list/due-date/{{cantDays}}
>```
### Headers

|Content-Type|Value|
|---|---|
|X-Auth-Token|{{token-fury}}|



⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃

## End-point: Req5 - 2

## Descripción:

Obtener todos los lotes próximos a vencer entre hoy y la cantidad de días posteriores ordenados por fecha de vencimiento. 

Que pertenecen a una determinada categoría de producto:
- FS=Fresco
- RF=Refrigerado
- FF=Congelado

### Method: GET
>```
>{{url-app}}/api/v1/fresh-products/batch/list/due-date/{{cantDays}}?category=FS&order=date_desc
>```
### Headers

|Content-Type|Value|
|---|---|
|X-Auth-Token|{{token-fury}}|


### Query Params

|Param|value|
|---|---|
|category|FS|
|category|RF|
|category|FF|
|order|date_asc|
|order|date_desc|



⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃ ⁃

