package com.mercadolibre.fp_be_java_hisp_w15_g01.factory;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.SectionRequestDTO;

public class SectionRequestDTOFactory {
    public static SectionRequestDTO create(int sectionCode, int warehouseCode) {
        return new SectionRequestDTO(sectionCode, warehouseCode);
    }
}
