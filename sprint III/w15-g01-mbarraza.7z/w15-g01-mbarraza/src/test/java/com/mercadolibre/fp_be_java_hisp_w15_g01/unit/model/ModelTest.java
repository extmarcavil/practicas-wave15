package com.mercadolibre.fp_be_java_hisp_w15_g01.unit.model;


import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Section;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.SectionEnum;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.SectionType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ModelTest {

    @Test
    public void test_section() {
        Section s = new Section();
        SectionType st = new SectionType(2L, 10D, SectionEnum.FRESH);
        s.setSectionType(st);
        s.setId(1L);
        s.setBatchLimit(10);
        s.setCurrentBatchAmount(5);
        s.isLowerTemperatureThan(s);
        Assertions.assertEquals(s, s);
    }
}
