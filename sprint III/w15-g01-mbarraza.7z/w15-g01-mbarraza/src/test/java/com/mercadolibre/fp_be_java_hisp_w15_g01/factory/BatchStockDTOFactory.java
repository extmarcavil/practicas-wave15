package com.mercadolibre.fp_be_java_hisp_w15_g01.factory;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.BatchStockDTO;

import java.util.ArrayList;
import java.util.List;

public class BatchStockDTOFactory {
    public static List<BatchStockDTO> createValid() {
        List<BatchStockDTO> ret = new ArrayList<>();

        BatchStockDTO b1 = new BatchStockDTO(1,1L,2D,2D,20,20,"01-06-2022","01-06-2022 00:00:00","01-06-2050");
        BatchStockDTO b2 = new BatchStockDTO(2,1L,2D,2D,20,20,"01-06-2022","01-06-2022 00:00:00","01-06-2050");
        BatchStockDTO b3 = new BatchStockDTO(3,1L,2D,2D,20,20,"01-06-2022","01-06-2022 00:00:00","01-06-2050");

        ret.add(b1);
        ret.add(b2);
        ret.add(b3);

        return ret;
    }

    public static List<BatchStockDTO> createOutOfSpace() {
        List<BatchStockDTO> ret = new ArrayList<>();

        for (int i = 0; i < 120; i++) {
            BatchStockDTO b1 = new BatchStockDTO(i, 1L, 2D, 2D, 20, 20, "01-06-2022", "01-06-2022 00:00:00", "01-06-2050");
            ret.add(b1);
        }

        return ret;
    }

    public static List<BatchStockDTO> createProductNotFound() {
        List<BatchStockDTO> ret = new ArrayList<>();

        BatchStockDTO b1 = new BatchStockDTO(1,999L,2D,2D,20,20,"01-06-2022","01-06-2022 00:00:00","01-06-2050");

        ret.add(b1);

        return ret;
    }

    public static List<BatchStockDTO> createNoSection() {
        List<BatchStockDTO> ret = new ArrayList<>();

        BatchStockDTO b1 = new BatchStockDTO(1,1L,200D,200D,20,20,"01-06-2022","01-06-2022 00:00:00","01-06-2050");

        ret.add(b1);

        return ret;
    }

    public static List<BatchStockDTO> createDuplicateBatches() {
        List<BatchStockDTO> ret = new ArrayList<>();

        BatchStockDTO b1 = new BatchStockDTO(1,1L,200D,200D,20,20,"01-06-2022","01-06-2022 00:00:00","01-06-2050");
        BatchStockDTO b2 = new BatchStockDTO(1,1L,200D,200D,20,20,"01-06-2022","01-06-2022 00:00:00","01-06-2050");

        ret.add(b1);
        ret.add(b2);

        return ret;
    }
}
