package com.mercadolibre.fp_be_java_hisp_w15_g01.integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class BuyerControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void test_integration_getproductlist() throws Exception {
        // Arrange
        //ObjectWriter writer = ObjectWriterFactory.create();

        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);

        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isOk();

        ResultMatcher expectedJson = MockMvcResultMatchers.jsonPath("$.[0].name").value("Tomate");

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .get("/api/v1/fresh-products/list");

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType, expectedJson);
    }
}
