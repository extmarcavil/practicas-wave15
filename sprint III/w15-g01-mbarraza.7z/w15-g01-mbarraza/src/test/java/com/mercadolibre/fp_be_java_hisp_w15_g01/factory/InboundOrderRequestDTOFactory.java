package com.mercadolibre.fp_be_java_hisp_w15_g01.factory;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.BatchStockDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.InboundOrderRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.SectionRequestDTO;

import java.util.List;

public class InboundOrderRequestDTOFactory {
    public static InboundOrderRequestDTO createBasic() {
        SectionRequestDTO section = SectionRequestDTOFactory.create(1,1);
        List<BatchStockDTO> batchStock = BatchStockDTOFactory.createValid();
        InboundOrderRequestDTO ret = new InboundOrderRequestDTO(1,"23-06-2022",section,batchStock);
        return ret;
    }

    public static InboundOrderRequestDTO createOutOfSpace() {
        SectionRequestDTO section = SectionRequestDTOFactory.create(1,1);
        List<BatchStockDTO> batchStock = BatchStockDTOFactory.createOutOfSpace();
        InboundOrderRequestDTO ret = new InboundOrderRequestDTO(1,"23-06-2022",section,batchStock);
        return ret;
    }

    public static InboundOrderRequestDTO createInvalidWarehouse() {
        SectionRequestDTO section = SectionRequestDTOFactory.create(1,9999);
        List<BatchStockDTO> batchStock = BatchStockDTOFactory.createValid();
        InboundOrderRequestDTO ret = new InboundOrderRequestDTO(1,"23-06-2022",section,batchStock);
        return ret;
    }

    public static InboundOrderRequestDTO createInvalidSection() {
        SectionRequestDTO section = SectionRequestDTOFactory.create(9999,1);
        List<BatchStockDTO> batchStock = BatchStockDTOFactory.createValid();
        InboundOrderRequestDTO ret = new InboundOrderRequestDTO(1,"23-06-2022",section,batchStock);
        return ret;
    }

    public static InboundOrderRequestDTO createProductNotFound() {
        SectionRequestDTO section = SectionRequestDTOFactory.create(1,1);
        List<BatchStockDTO> batchStock = BatchStockDTOFactory.createProductNotFound();
        InboundOrderRequestDTO ret = new InboundOrderRequestDTO(1,"23-06-2022",section,batchStock);
        return ret;
    }

    public static InboundOrderRequestDTO createSectionNotFound() {
        SectionRequestDTO section = SectionRequestDTOFactory.create(3,1);
        List<BatchStockDTO> batchStock = BatchStockDTOFactory.createNoSection();
        InboundOrderRequestDTO ret = new InboundOrderRequestDTO(1,"23-06-2022",section,batchStock);
        return ret;
    }

    public static InboundOrderRequestDTO createDuplicateBatches() {
        SectionRequestDTO section = SectionRequestDTOFactory.create(1,1);
        List<BatchStockDTO> batchStock = BatchStockDTOFactory.createDuplicateBatches();
        InboundOrderRequestDTO ret = new InboundOrderRequestDTO(1,"23-06-2022",section,batchStock);
        return ret;
    }
}
