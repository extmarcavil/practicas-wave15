package com.mercadolibre.fp_be_java_hisp_w15_g01.integration;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.WarehouseEntryRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.WarehouseEntryResponseDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.factory.ObjectWriterFactory;
import com.mercadolibre.fp_be_java_hisp_w15_g01.factory.WarehouseEntryRequestDTOFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)

public class WarehouseControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void test_integration_postInboundOrder() throws Exception {
        // Arrange
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createValid();
        String payload = writer.writeValueAsString(reqDto);
        String resPayload = writer.writeValueAsString(new WarehouseEntryResponseDTO(reqDto.getInboundOrder().getBatchStock()));
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isOk();
        ResultMatcher expectedJson = MockMvcResultMatchers
                .content()
                .json(resPayload);

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType, expectedJson);
    }

    @Test
    public void test_integration_postInboundOrder_duplicateID() throws Exception {
        // Arrange
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createValid();
        String payload = writer.writeValueAsString(reqDto);
        String resPayload = writer.writeValueAsString(new WarehouseEntryResponseDTO(reqDto.getInboundOrder().getBatchStock()));
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isOk();
        ResultMatcher expectedJson = MockMvcResultMatchers
                .content()
                .json(resPayload);

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print());
        // Arrange


        expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        expectedStatus = MockMvcResultMatchers
                .status()
                .is4xxClientError();


        // Act
        request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType);
    }

    @Test
    public void test_integration_postInboundOrder_out_of_space() throws Exception {
        // Arrange
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createOutOfSpace();
        String payload = writer.writeValueAsString(reqDto);
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isBadRequest();

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType);
    }

    @Test
    public void test_integration_invalid_warehouse() throws Exception {
        // Arrange
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createInvalid();
        String payload = writer.writeValueAsString(reqDto);
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isNotFound();

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType);
    }

    @Test
    public void test_integration_invalid_section() throws Exception {
        // Arrange
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createInvalidSection();
        String payload = writer.writeValueAsString(reqDto);
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isBadRequest();

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType);
    }

    @Test
    public void test_integration_product_not_found() throws Exception {
        // Arrange
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createWithProductNotFound();
        String payload = writer.writeValueAsString(reqDto);
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isNotFound();

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType);
    }

    @Test
    public void test_integration_section_not_found() throws Exception {
        // Arrange
        //TO DO: FIX ERROR CODE
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createWithSectionNotFound();
        String payload = writer.writeValueAsString(reqDto);
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .is4xxClientError();

        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType);
    }

    @Test
    public void test_integration_error() throws Exception {
        // Arrange
        ObjectWriter writer = ObjectWriterFactory.create();
        WarehouseEntryRequestDTO reqDto = WarehouseEntryRequestDTOFactory.createDuplicateBatches();
        String payload = writer.writeValueAsString(reqDto);
        ResultMatcher expectedContentType = MockMvcResultMatchers
                .content()
                .contentType(MediaType.APPLICATION_JSON);
        ResultMatcher expectedStatus = MockMvcResultMatchers
                .status()
                .isBadRequest();
        // Act
        MockHttpServletRequestBuilder request = MockMvcRequestBuilders
                .post("/api/v1/fresh-products/inboundorder")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payload);

        // Asert
        mockMvc
                .perform(request)
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(expectedStatus, expectedContentType);
    }




}
