package com.mercadolibre.fp_be_java_hisp_w15_g01.factory;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.WarehouseEntryRequestDTO;

public class WarehouseEntryRequestDTOFactory {
    public static WarehouseEntryRequestDTO createValid() {
        return new WarehouseEntryRequestDTO(InboundOrderRequestDTOFactory.createBasic());
    }

    public static WarehouseEntryRequestDTO createOutOfSpace() {
        return new WarehouseEntryRequestDTO(InboundOrderRequestDTOFactory.createOutOfSpace());
    }

    public static WarehouseEntryRequestDTO createInvalid() {
        return new WarehouseEntryRequestDTO(InboundOrderRequestDTOFactory.createInvalidWarehouse());
    }

    public static WarehouseEntryRequestDTO createInvalidSection() {
        return new WarehouseEntryRequestDTO(InboundOrderRequestDTOFactory.createInvalidSection());
    }

    public static WarehouseEntryRequestDTO createWithProductNotFound() {
        return new WarehouseEntryRequestDTO(InboundOrderRequestDTOFactory.createProductNotFound());
    }

    public static WarehouseEntryRequestDTO createWithSectionNotFound() {
        return new WarehouseEntryRequestDTO(InboundOrderRequestDTOFactory.createSectionNotFound());
    }

    public static WarehouseEntryRequestDTO createDuplicateBatches() {
        return new WarehouseEntryRequestDTO(InboundOrderRequestDTOFactory.createDuplicateBatches());
    }
}
