-- Los usuarios de prueba se insertan manualmente vía DBAccess
-- Enums
INSERT INTO `roles` (id,`role`) VALUES (1, 'ADMIN');
INSERT INTO `roles` (id,`role`) VALUES (2, 'SELLER');
INSERT INTO `roles` (id,`role`) VALUES (3, 'BUYER');

INSERT INTO order_status (id, status_code) VALUES (1, 'CART');
INSERT INTO order_status (id, status_code) VALUES (2, 'PAID');

INSERT INTO users (id,username,password) VALUES (1,'ADMIN','ADMIN');
INSERT INTO users (id,username,password) VALUES (2,'SELLER','SELLER');
INSERT INTO users (id,username,password) VALUES (3,'BUYER','BUYER');

INSERT INTO users_roles (user_id, role_id) VALUES (1,1);
INSERT INTO users_roles (user_id, role_id) VALUES (2,2);
INSERT INTO users_roles (user_id, role_id) VALUES (3,3);

INSERT INTO products (id, name, user_id, accessibility, accessibility_tags) VALUES (1, 'Tomate', 2, true, 'caja braille, con alto contraste');
INSERT INTO products (id, name, user_id, accessibility, accessibility_tags) VALUES (2, 'Leche', 2, false, '');
INSERT INTO products (id, name, user_id, accessibility, accessibility_tags) VALUES (3, 'Carne', 2, false, '');
INSERT INTO products (id, name, user_id, accessibility, accessibility_tags) VALUES (4, 'Carne', 2, true, 'qr con info web accesible');

INSERT INTO warehouses (id, address) VALUES (1, 'Calle Falsa 123');

INSERT INTO section_types (id, section_name, temperature) VALUES (1, 'FRESH', 10);
INSERT INTO section_types (id, section_name, temperature) VALUES (2, 'REFRIGERATED', 1);
INSERT INTO section_types (id, section_name, temperature) VALUES (3, 'FROZEN', -2);

INSERT INTO `sections` (id, section_type_id, batch_limit, current_batch_amount) VALUES (1, 1, 100, 0);
INSERT INTO `sections` (id, section_type_id, batch_limit, current_batch_amount) VALUES (2, 2, 100, 0);
INSERT INTO `sections` (id, section_type_id, batch_limit, current_batch_amount) VALUES (3, 3, 100, 0);

INSERT INTO warehouses_sections VALUES (1, 1);
INSERT INTO warehouses_sections VALUES (1, 2);
INSERT INTO warehouses_sections VALUES (1, 3);