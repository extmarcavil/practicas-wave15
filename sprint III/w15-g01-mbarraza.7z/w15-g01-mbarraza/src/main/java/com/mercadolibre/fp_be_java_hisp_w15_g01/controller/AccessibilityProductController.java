package com.mercadolibre.fp_be_java_hisp_w15_g01.controller;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.ProductDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.ProductDataDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.ProductAccessibilityRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.ProductRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.WarehouseEntryRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.WarehouseEntryResponseDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/fresh-products")
public class AccessibilityProductController {

    ProductService productService;

    public AccessibilityProductController(ProductService productService) {
        this.productService = productService;
    }


    @GetMapping("/list/accessibility")
    public ResponseEntity<List<ProductDataDTO>> getProductList(@RequestParam(required = false) String category) {
        return ResponseEntity.ok(productService.getProductsAccessibility(category));
    }

    @PostMapping("/products/accessibility")
    public ResponseEntity<ProductDataDTO> postUpdateProduct(@RequestBody @Valid ProductAccessibilityRequestDTO dto) {
        return ResponseEntity.ok(productService.UpdateProductAccessibility(dto.getProductId(), dto.getAccessibilityTags()));
    }
    
    @PostMapping("/products/accessibility/disable")
    public ResponseEntity<ProductDataDTO> disableProductAccessibility(@RequestBody @Valid ProductRequestDTO dto) {
        return ResponseEntity.ok(productService.disableProductAccessibility(dto.getProductId()));
    }
    
    
}
