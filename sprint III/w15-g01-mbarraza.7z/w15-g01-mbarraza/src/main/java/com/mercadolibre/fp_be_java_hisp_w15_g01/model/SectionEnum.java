package com.mercadolibre.fp_be_java_hisp_w15_g01.model;

public enum SectionEnum {
    FROZEN,
    REFRIGERATED,
    FRESH;
}
