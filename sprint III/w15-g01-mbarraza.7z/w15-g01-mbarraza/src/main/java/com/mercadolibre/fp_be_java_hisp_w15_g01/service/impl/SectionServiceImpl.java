package com.mercadolibre.fp_be_java_hisp_w15_g01.service.impl;

import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Section;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.SectionService;
import org.springframework.stereotype.Service;

@Service
public class SectionServiceImpl implements SectionService {
}
