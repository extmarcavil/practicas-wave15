package com.mercadolibre.fp_be_java_hisp_w15_g01.service.impl;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.BatchProductDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.BatchStockDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.InboundOrderRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.BatchListByDaysResponseDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.WarehouseEntryResponseDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.ExistentIdException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.InvalidArgumentException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.NoSpaceException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Batch;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Product;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Section;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.SectionEnum;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.SectionEnum.*;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Warehouse;
import com.mercadolibre.fp_be_java_hisp_w15_g01.repository.BatchRepository;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.BatchService;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.ProductService;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.SectionService;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.WarehouseService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BatchServiceImpl implements BatchService {
    private final BatchRepository repo;
    private final ProductService productService;
    private final WarehouseService warehouseService;
    private final SectionService sectionService;
    private final ModelMapper mapper;

    public BatchServiceImpl(
            BatchRepository repo,
            ProductService productService,
            WarehouseService warehouseService,
            SectionService sectionService,
            ModelMapper mapper
    ) {
        this.repo = repo;
        this.productService = productService;
        this.warehouseService = warehouseService;
        this.sectionService = sectionService;
        this.mapper = mapper;
    }

    @Override
    @Transactional
    public WarehouseEntryResponseDTO postInboundOrder(InboundOrderRequestDTO dto) {
        Section section = warehouseService.performWarehouseChecks(dto);
        if (!section.hasSpaceFor(dto.getBatchStock().size())) {
            throw new NoSpaceException();
        }
        List<Batch> savedBatches = new ArrayList<>();
        dto
                .getBatchStock()
                .stream()
                .forEach(stock -> {
                    Product p = productService.checkProductExists(stock.getProductId());
                    savedBatches.add(saveBatch(stock, p, section));
                });

        section.addBatches(savedBatches);
        List<BatchStockDTO> dtos = savedBatches
                .stream()
                .map(model -> mapToDto(model))
                .collect(Collectors.toList());
        return new WarehouseEntryResponseDTO(dtos);
    }

    private BatchStockDTO mapToDto(Batch model) {
        BatchStockDTO dto = mapper.map(model, BatchStockDTO.class);
        dto.setDueDate(model.getDueDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        dto.setManufacturingDate(model.getManufactureDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        dto.setManufacturingTime(model.getManufactureTime().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
        dto.setBatchNumber(model.getId().intValue());
        return dto;
    }

    private Batch saveBatch(BatchStockDTO batch, Product p, Section section) {
        if (repo.existsById(batch.getBatchNumber().longValue())) {
            throw new ExistentIdException("Ya existe un lote con ese id");
        }
        Batch model = mapper.map(batch, Batch.class);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        model.setDueDate(LocalDate.parse(batch.getDueDate(), formatter));
        model.setManufactureDate(LocalDate.parse(batch.getManufacturingDate(), formatter));
        model.setManufactureTime(LocalDateTime.parse(batch.getManufacturingTime(), timeFormatter));
        model.setProduct(p);
        model.setId(batch.getBatchNumber().longValue());
        model.setSection(section);
        return repo.save(model);    }

    @Override
    @Transactional
	public BatchListByDaysResponseDTO getBatchByDays(Integer cantDays, String category, String order) {
		BatchListByDaysResponseDTO dto = new BatchListByDaysResponseDTO();
		LocalDate now = LocalDate.now();
		LocalDate date2 = now.plusDays(cantDays);
		List<Batch> batches; 
		if(category.equals("")) {
			batches = getAllBatch(now, date2);
		} else if (category.equals("FS") || category.equals("RF") || category.equals("FF")) {
			batches = getAllBatchBySection(category, now, date2);
		} else {
			throw new InvalidArgumentException("Invalid Parameter. category not valid"); 
		}
		
		batches = orderBatches(batches, order);
		dto.setBatchStock(this.mapperDtoBatches(batches));

		
		
		return dto;
	}
    
    
    private List<Batch> orderBatches(List<Batch> batches, String order) {
    	if(order != null && !order.equals("date_asc") && !order.equals("date_desc")) {
            throw new InvalidArgumentException("Invalid sorting Parameter. Must be order_desc or order_asc");
        }

    	batches = batches.stream()
                .sorted(Comparator.comparing(Batch::getDueDate))
                .collect(Collectors.toList());

        if(order.equals("date_desc")) {
            Collections.reverse(batches);
        }


		return batches;
	}

	private List<BatchProductDTO> mapperDtoBatches(List<Batch> batches) {
		return batches.stream().map(b -> this.mapDtoBatches(b)).collect(Collectors.toList());
	}
    
    private BatchProductDTO mapDtoBatches(Batch batch) {

    BatchProductDTO dto = new BatchProductDTO();
    dto.setProductId(batch.getProduct().getId());
    dto.setQuantity(batch.getCurrentQuantity());
    dto.setDueDate(batch.getDueDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
    dto.setBatchNumber(batch.getId().intValue());
    dto.setProductTypeId(batch.getSection().getSectionType().getSectionName().toString());
    return dto;
}

	private List<Batch> getAllBatch(LocalDate date1, LocalDate date2) {
    return warehouseService.listAll()
                .stream()
                .flatMap(w -> w.getSections().stream())
                .flatMap(s -> s.getBatches().stream()
                .filter(b -> b.getDueDate().isEqual(date1) || (b.getDueDate().isBefore(date2) && b.getDueDate().isAfter(date1))))
                .collect(Collectors.toList());
    }
	
	private List<Batch> getAllBatchBySection(String category, LocalDate date1, LocalDate date2) {
		Map<String, SectionEnum> sectionMap = Map.of(
                "FS", SectionEnum.FRESH,
                "RF", SectionEnum.REFRIGERATED,
                "FF", SectionEnum.FROZEN);

		
	    return warehouseService.listAll()
	                .stream()
	                .flatMap(w -> w.getSections().stream())
	                .filter(s -> s.getSectionType().getSectionName() == sectionMap.get(category))
	                .flatMap(s -> s.getBatches().stream()
	                .filter(b -> b.getDueDate().isEqual(date1) || (b.getDueDate().isBefore(date2) && b.getDueDate().isAfter(date1))))
	                .collect(Collectors.toList());
	    }

}

