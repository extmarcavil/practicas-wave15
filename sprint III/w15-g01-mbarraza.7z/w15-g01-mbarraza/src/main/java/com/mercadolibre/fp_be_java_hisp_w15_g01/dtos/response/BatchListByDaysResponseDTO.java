package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response;

import java.util.List;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.BatchProductDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Batch;

import lombok.Data;

@SuppressWarnings("unused")
@Data
public class BatchListByDaysResponseDTO {
	private List<BatchProductDTO> batchStock;
}
