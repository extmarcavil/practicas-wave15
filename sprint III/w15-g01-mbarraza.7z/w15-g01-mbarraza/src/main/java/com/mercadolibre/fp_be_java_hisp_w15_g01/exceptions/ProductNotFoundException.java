package com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions;

public class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(Long id) {
        super("No existe el producto con id " + id);
    }
}
