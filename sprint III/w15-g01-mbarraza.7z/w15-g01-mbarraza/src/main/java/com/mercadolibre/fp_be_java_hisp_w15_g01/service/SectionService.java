package com.mercadolibre.fp_be_java_hisp_w15_g01.service;

public interface SectionService {


}
