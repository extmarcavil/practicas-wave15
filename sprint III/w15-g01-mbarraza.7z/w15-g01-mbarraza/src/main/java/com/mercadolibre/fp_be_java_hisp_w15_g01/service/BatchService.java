package com.mercadolibre.fp_be_java_hisp_w15_g01.service;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.BatchListByDaysResponseDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.InboundOrderRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.WarehouseEntryResponseDTO;

public interface BatchService {

    WarehouseEntryResponseDTO postInboundOrder(InboundOrderRequestDTO dto);
    BatchListByDaysResponseDTO getBatchByDays(Integer cantDays, String category, String order);

}
