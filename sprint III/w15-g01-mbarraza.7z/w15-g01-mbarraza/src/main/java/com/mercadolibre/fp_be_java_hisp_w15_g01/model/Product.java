package com.mercadolibre.fp_be_java_hisp_w15_g01.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@Entity
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User seller;
    
    @Column(name = "accessibility", nullable = false)
    private Boolean accessibility;
    
    @Column(name = "accessibilityTags", nullable = false)
    private String accessibilityTags;
}
