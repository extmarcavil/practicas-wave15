package com.mercadolibre.fp_be_java_hisp_w15_g01.repository;

import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Section;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SectionRepository extends JpaRepository<Section, Long> {
}
