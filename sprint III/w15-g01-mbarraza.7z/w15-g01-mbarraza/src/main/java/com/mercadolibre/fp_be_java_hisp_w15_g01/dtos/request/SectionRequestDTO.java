package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mercadolibre.fp_be_java_hisp_w15_g01.constants.ValidationValues;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SectionRequestDTO {
    @JsonProperty("section_code")
    @Min(value = ValidationValues.SECTION_CODE_MIN, message = ValidationValues.SECTION_CODE_MESSAGE)
    private Integer sectionCode;


    @JsonProperty("warehouse_code")
    @Min(value = ValidationValues.WAREHOUSE_CODE_MIN, message = ValidationValues.WAREHOUSE_CODE_MESSAGE)
    private Integer warehouseCode;
}
