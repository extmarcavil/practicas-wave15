package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponseDTO {
    private Boolean success = false;
    private String message;

    public ErrorResponseDTO(String message) {
        this.message = message;
    }
}
