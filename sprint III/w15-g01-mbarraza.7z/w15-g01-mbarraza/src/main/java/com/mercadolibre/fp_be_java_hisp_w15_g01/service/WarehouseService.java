package com.mercadolibre.fp_be_java_hisp_w15_g01.service;

import java.util.List;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.InboundOrderRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Section;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Warehouse;
public interface WarehouseService {
    Section performWarehouseChecks(InboundOrderRequestDTO dto);

	List<Warehouse> listAll();
}
