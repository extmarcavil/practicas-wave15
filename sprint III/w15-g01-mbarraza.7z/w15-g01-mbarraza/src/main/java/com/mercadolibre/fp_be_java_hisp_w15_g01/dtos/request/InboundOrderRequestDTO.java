package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request;

import com.mercadolibre.fp_be_java_hisp_w15_g01.constants.ValidationValues;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.BatchStockDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InboundOrderRequestDTO {
    @Min(value = ValidationValues.ORDER_NUNBER_MIN, message = ValidationValues.ORDER_NUNBER_MESSAGE)
    private Integer orderNumber;

    @Pattern(regexp = ValidationValues.DATE_REGEX, message = ValidationValues.DATE_FORMAT)
    @NotNull(message = ValidationValues.DATE_NOT_NULL)
    private String orderDate;

    @NotNull(message = ValidationValues.ORDER_SECTION)
    private SectionRequestDTO section;

    @NotNull(message = ValidationValues.BATCH_STOCK_NOT_NULL)
    private List<BatchStockDTO> batchStock;
}
