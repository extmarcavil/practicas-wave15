package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mercadolibre.fp_be_java_hisp_w15_g01.constants.ValidationValues;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BatchStockDTO {
    @JsonProperty("batch_number")
    @Min(value = 1, message = "El numero de lote debe ser mayor a 0")
    private Integer batchNumber;

    @JsonProperty("product_id")
    @Min(value = 1, message = "El id del producto no puede ser menor a 1")
    private Long productId;

    @JsonProperty("current_temperature")
    @Min(value = -50, message = "La temperature actual no puede ser menor a 50 grados")
    @Max(value = 10, message = "La temperatura actual no puede ser mayor a 10 grados")
    private Double temperature;

    @JsonProperty("minimum_temperature")
    @Min(value = -50, message = "La temperature minima no puede ser menor a 50 grados")
    @Max(value = 10, message = "La temperatura minima no puede ser mayor a 10 grados")
    private Double minimumTemperature;

    @JsonProperty("initial_quantity")
    @Min(value =1, message = "La cantidad inicial debe ser mayor a 0")
    private Integer initialQuantity;

    @JsonProperty("current_quantity")
    @Min(value = 0, message = "La cantidad actual debe ser mayor o igual a 0")
    private Integer currentQuantity;

    @JsonProperty("manufacturing_date")
    @Pattern(regexp = ValidationValues.DATE_REGEX, message = ValidationValues.DATE_FORMAT)
    @NotNull(message = ValidationValues.DATE_NOT_NULL)
    private String manufacturingDate;

    @JsonProperty("manufacturing_time")
    private String manufacturingTime;

    @JsonProperty("due_date")
    @Pattern(regexp = ValidationValues.DATE_REGEX, message = ValidationValues.DATE_FORMAT)
    @NotNull(message = ValidationValues.DATE_NOT_NULL)
    private String dueDate;
}
