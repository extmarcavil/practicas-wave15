package com.mercadolibre.fp_be_java_hisp_w15_g01.service.impl;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.InboundOrderRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.InvalidSectionTypeException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.SectionNotFoundException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.WarehouseNotFoundException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Section;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Warehouse;
import com.mercadolibre.fp_be_java_hisp_w15_g01.repository.WarehouseRepository;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.WarehouseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class WarehouseServiceImpl implements WarehouseService {
    private final WarehouseRepository repo;

    public WarehouseServiceImpl(WarehouseRepository repo) {
        this.repo = repo;
    }

    @Override
    @Transactional
    public Section performWarehouseChecks(InboundOrderRequestDTO dto) {
        Integer warehouseCode = dto.getSection().getWarehouseCode();
        Integer sectionCode = dto.getSection().getSectionCode();
        Optional<Warehouse> ow = this.repo.findById(warehouseCode.longValue());
        checkWarehouseNotEmpty(ow, warehouseCode);
        Warehouse w = ow.get();
        checkCorrespondingSector(sectionCode, w, dto);
        return checkValidSector(sectionCode, w);
    }

    private void checkCorrespondingSector(Integer sectionCode, Warehouse w, InboundOrderRequestDTO dto) {
        Section section = w
                .getSections()
                .stream()
                .filter(s -> s.isTemperatureGreaterThan(dto.getBatchStock().get(0).getMinimumTemperature()))
                .reduce(null, (acc, s) -> {
                    if (acc == null) return s;
                    else return minorTemperatureBetween(s, acc);
                });
        if (section == null || !section.sectionTypeIdEquals(dto.getSection().getSectionCode().longValue())) {
            throw new InvalidSectionTypeException();
        }
    }

    private Section minorTemperatureBetween(Section s1, Section s2) {
        Section ret = s1;
        if (!s1.isLowerTemperatureThan(s2)) {
            ret = s2;
        }
        return ret;
    }

    private void checkWarehouseNotEmpty(Optional<Warehouse> ow, Integer warehouseCode) {
        if (ow.isEmpty()) {
            throw new WarehouseNotFoundException(warehouseCode);
        }
    }

    private Section checkValidSector(Integer sectionCode, Warehouse w) {
        return w
                .getSections()
                .stream()
                .filter(s -> s.getId().equals(sectionCode.longValue()))
                .findFirst()
                .orElseThrow(() -> { throw new SectionNotFoundException(sectionCode); });
    }

	@Override
	public List<Warehouse> listAll() {
		return this.repo.findAll();
	}
}
