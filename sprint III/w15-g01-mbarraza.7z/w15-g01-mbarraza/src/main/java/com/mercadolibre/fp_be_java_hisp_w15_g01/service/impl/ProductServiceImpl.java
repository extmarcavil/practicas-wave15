package com.mercadolibre.fp_be_java_hisp_w15_g01.service.impl;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.ProductDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.ProductDataDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.EmptyListException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions.ProductNotFoundException;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.*;
import com.mercadolibre.fp_be_java_hisp_w15_g01.repository.ProductRepository;
import com.mercadolibre.fp_be_java_hisp_w15_g01.repository.WarehouseRepository;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.ProductService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;

import static com.mercadolibre.fp_be_java_hisp_w15_g01.model.SectionEnum.*;

@Service
public class ProductServiceImpl implements ProductService {
    private final ProductRepository repo;
    private final WarehouseRepository warehouseRepo;

    private final ModelMapper mapper;



    public ProductServiceImpl(ProductRepository productRepository, WarehouseRepository warehouseRepo, ModelMapper mapper) {
        this.repo = productRepository;
        this.warehouseRepo = warehouseRepo;
        this.mapper = mapper;

    }

    /*
    @Override
    public Boolean existsById(Long id) {
        return repo.existsById(id);
    }
    */

    @Override
    public Product checkProductExists(Long id) {
        Optional<Product> op = repo.findById(id);
        if (op.isEmpty()) {
            throw new ProductNotFoundException(id);
        }
        return op.get();
    }

    @Override
    @Transactional
    public List<ProductDTO> getProducts(String category) {

        List<Product> products = new ArrayList<>();

        if(category == null) {
            products = repo.findAll();
        } else {
            Map<String, SectionEnum> sectionMap = Map.of(
                    "FS", FRESH,
                    "RF", REFRIGERATED,
                    "FF", FROZEN);

           products = warehouseRepo.findAll()
                   .stream()
                   .flatMap(w -> w.getSections().stream())
                   .filter(s -> s.getSectionType().getSectionName() == sectionMap.get(category))
                   .flatMap(s -> s.getBatches().stream())
                   .map(Batch::getProduct).distinct().collect(Collectors.toList());
        }

        if(products.isEmpty())
            throw new EmptyListException("No existen productos en la sección solicitada o en general");

        return products.stream().map(p->mapper.map(p, ProductDTO.class)).collect(Collectors.toList());
    }

	@Override
	@Transactional
	public List<ProductDataDTO> getProductsAccessibility(String category) {
		List<Product> products = this.getProductsAccesibilityAllByCategory(category);
        if(products.isEmpty())
            throw new EmptyListException("There are no products with accessibility");

        return products.stream()
        		.map(p -> this.mapperToProductDto(p))
        		.collect(Collectors.toList());
	}
	
	private List<Product> getProductsAccesibilityAllByCategory(String category) {
		List<Product> products = new ArrayList<>();
        if(category == null) {
            products = repo.findAll().stream()
            		.filter(p -> p.getAccessibility())
            		.collect(Collectors.toList());
        } else {
            Map<String, SectionEnum> sectionMap = Map.of(
                    "FS", FRESH,
                    "RF", REFRIGERATED,
                    "FF", FROZEN);

           products = warehouseRepo.findAll()
                   .stream()
                   .flatMap(w -> w.getSections().stream())
                   .filter(s -> s.getSectionType().getSectionName() == sectionMap.get(category))
                   .flatMap(s -> s.getBatches().stream())
                   .map(Batch::getProduct).distinct()
                   .filter(p -> p.getAccessibility())
                   .collect(Collectors.toList());
        }


		return products;
	}

	private ProductDataDTO mapperToProductDto(Product product) {
		ProductDataDTO p = new ProductDataDTO();
		p.setId(Math.toIntExact( product.getId() ));
		p.setName(product.getName());
		p.setAccesibility(product.getAccessibilityTags());
		return p;
	}

	@Override
	@Transactional
	public ProductDataDTO UpdateProductAccessibility(Integer productId, String accessibilityTags) {
		Product p = this.getById(Long.valueOf(productId));
		p.setAccessibility(true);
		p.setAccessibilityTags(accessibilityTags);
		this.repo.save(p);
		return this.mapperToProductDto(p);
	}

	private Product getById(Long productId) {
		Optional<Product> p = this.repo.findById(Long.valueOf(productId));
		if (p.isPresent()) {
            return p.get();
        } else {
        	throw new ProductNotFoundException(productId);
        }
	}

	@Override
	@Transactional
	public ProductDataDTO disableProductAccessibility(Integer productId) {
		Product p = this.getById(Long.valueOf(productId));
		p.setAccessibility(false);
		p.setAccessibilityTags("");
		this.repo.save(p);
		return this.mapperToProductDto(p);
	}
}
