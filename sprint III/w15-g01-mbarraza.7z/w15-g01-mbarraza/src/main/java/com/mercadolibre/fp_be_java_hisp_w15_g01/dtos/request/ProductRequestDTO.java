package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request;

import javax.validation.constraints.Min;

import com.mercadolibre.fp_be_java_hisp_w15_g01.constants.ValidationValues;

import lombok.Data;

@Data
public class ProductRequestDTO {
	@Min(value = ValidationValues.ORDER_NUNBER_MIN, message = ValidationValues.ORDER_NUNBER_MESSAGE)
    private Integer productId;
}
