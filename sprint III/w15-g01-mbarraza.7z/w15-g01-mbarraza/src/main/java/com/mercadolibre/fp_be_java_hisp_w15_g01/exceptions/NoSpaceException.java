package com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions;

public class NoSpaceException extends RuntimeException {
    public NoSpaceException() {
        super("No hay espeacio en la seccion");
    }
}
