package com.mercadolibre.fp_be_java_hisp_w15_g01.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sections")
public class Section {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name="section_type_id", nullable = false)
    private SectionType sectionType;

    @Column(name = "batch_limit")
    private Integer batchLimit;

    @Column(name = "current_batch_amount")
    private Integer currentBatchAmount;

    @OneToMany(fetch = FetchType.LAZY)
    private List<Batch> batches = new ArrayList<>();

    public boolean isTemperatureGreaterThan(Double minimumTemperature) {
        return sectionType.getTemperature() >= minimumTemperature;
    }

    public boolean sectionTypeIdEquals(long longValue) {
        return sectionType.getId().equals(longValue);
    }

    public boolean isLowerTemperatureThan(Section s) {
        return sectionType.getTemperature() < s.getTemperature();
    }

    private Double getTemperature() {
        return this.sectionType.getTemperature();
    }

    public boolean hasSpaceFor(int size) {
        return batchLimit - currentBatchAmount >= size;
    }

    public void addBatches(List<Batch> batches) {
        this.batches.addAll(batches);
    }
}
