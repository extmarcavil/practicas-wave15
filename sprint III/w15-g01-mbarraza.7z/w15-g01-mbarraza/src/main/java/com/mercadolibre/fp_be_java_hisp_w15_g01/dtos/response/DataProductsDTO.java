package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response;

public class DataProductsDTO {

}
