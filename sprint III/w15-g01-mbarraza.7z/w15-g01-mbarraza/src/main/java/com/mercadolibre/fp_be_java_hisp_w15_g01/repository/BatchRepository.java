package com.mercadolibre.fp_be_java_hisp_w15_g01.repository;

import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Batch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BatchRepository extends JpaRepository<Batch, Long> {
}
