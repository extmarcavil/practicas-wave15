package com.mercadolibre.fp_be_java_hisp_w15_g01.service;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.ProductDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.ProductDataDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.model.Product;

import java.util.List;

import javax.validation.constraints.NotNull;

public interface ProductService {

    //Boolean existsById(Long id);

    Product checkProductExists(Long productId);

    List<ProductDTO> getProducts(String category);

    List<ProductDataDTO> getProductsAccessibility(String category);

	ProductDataDTO UpdateProductAccessibility(Integer productId, String accessibilityTags);

	ProductDataDTO disableProductAccessibility(Integer productId);




}
