package com.mercadolibre.fp_be_java_hisp_w15_g01.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "section_types")
public class SectionType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "temperature", nullable = false)
    private Double temperature;

    @Enumerated(EnumType.STRING)
    @Column(name = "section_name", nullable = false, unique = true)
    private SectionEnum sectionName;
}
