package com.mercadolibre.fp_be_java_hisp_w15_g01.controller;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request.WarehouseEntryRequestDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.BatchListByDaysResponseDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.response.WarehouseEntryResponseDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.impl.BatchServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/fresh-products")
public class WarehouseController {
    private final BatchServiceImpl batchService;

    public WarehouseController(BatchServiceImpl batchService) {
        this.batchService = batchService;
    }

    @PostMapping("/inboundorder")
    public ResponseEntity<WarehouseEntryResponseDTO> postInboundOrder(@RequestBody @Valid WarehouseEntryRequestDTO dto) {
        return ResponseEntity.ok(batchService.postInboundOrder(dto.getInboundOrder()));
    }
    
    @GetMapping("/batch/list/due-date/{cantDays}")
    public ResponseEntity<BatchListByDaysResponseDTO> getBatchByDays(@PathVariable Integer cantDays, @RequestParam(name = "category", required = false, defaultValue = "") String category, @RequestParam(name = "order", required = false, defaultValue = "date_asc") String order) {
        return ResponseEntity.ok(batchService.getBatchByDays(cantDays, category, order));
    }


}
