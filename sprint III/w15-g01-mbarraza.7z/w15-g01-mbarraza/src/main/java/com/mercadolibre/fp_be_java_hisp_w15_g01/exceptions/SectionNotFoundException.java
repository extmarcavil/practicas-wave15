package com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions;

public class SectionNotFoundException extends RuntimeException {
    public SectionNotFoundException(Integer sectionCode) {
        super("No existe la seccion con codigo " + sectionCode);
    }
}
