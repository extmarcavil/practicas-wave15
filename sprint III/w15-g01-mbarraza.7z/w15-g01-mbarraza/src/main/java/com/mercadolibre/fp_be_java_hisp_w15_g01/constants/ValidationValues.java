package com.mercadolibre.fp_be_java_hisp_w15_g01.constants;

public class ValidationValues {

    public static final int ORDER_NUNBER_MIN = 1;
    public static final String ORDER_NUNBER_MESSAGE = "El numero de orden debe ser mayor a 0";

    public static final String ORDER_SECTION = "La seccion no puede ser nula";

    public static final String DATE_NOT_NULL = "La fecha no puede ser nula";
    public static final String DATE_FORMAT = "El formato de la fecha debe ser dd-MM-yyyy";
    public static final String DATE_REGEX = "^(?:3[01]|[12][0-9]|0?[1-9])([\\-/.])(0?[1-9]|1[1-2])\\1\\d{4}$";
    public static final String BATCH_STOCK_NOT_NULL = "El stock de lotes no puede ser nulo";

    public static final int SECTION_CODE_MIN = 1;
    public static final String SECTION_CODE_MESSAGE = "El numero de seccion debe ser mayor a 0";

    public static final int WAREHOUSE_CODE_MIN = 1;
    public static final String WAREHOUSE_CODE_MESSAGE = "El numero del warehouse debe ser mayor a 0";
}
