package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.request;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.mercadolibre.fp_be_java_hisp_w15_g01.constants.ValidationValues;

import lombok.Data;

@Data
public class ProductAccessibilityRequestDTO {
	@Min(value = ValidationValues.ORDER_NUNBER_MIN, message = ValidationValues.ORDER_NUNBER_MESSAGE)
    private Integer productId;

	@NotNull(message = ValidationValues.DATE_NOT_NULL)
    private String accessibilityTags;
}
