package com.mercadolibre.fp_be_java_hisp_w15_g01.controller;

import com.mercadolibre.fp_be_java_hisp_w15_g01.dtos.ProductDTO;
import com.mercadolibre.fp_be_java_hisp_w15_g01.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/fresh-products")
public class BuyerController {

    ProductService productService;

    public BuyerController(ProductService productService) {
        this.productService = productService;
    }


    @GetMapping("/list")
    public ResponseEntity<List<ProductDTO>> getProductList(@RequestParam(required = false) String category) {
        return ResponseEntity.ok(productService.getProducts(category));
    }




}
