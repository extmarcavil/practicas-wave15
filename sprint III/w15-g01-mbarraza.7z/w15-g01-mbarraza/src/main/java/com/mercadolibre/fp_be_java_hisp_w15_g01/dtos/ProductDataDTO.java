package com.mercadolibre.fp_be_java_hisp_w15_g01.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDataDTO {
	private Integer id;
	private String name;
	private String accesibility;
}
