package com.mercadolibre.fp_be_java_hisp_w15_g01.exceptions;

public class WarehouseNotFoundException extends RuntimeException {
    public WarehouseNotFoundException(Integer warehouseCode) {
        super("No se encontro el warehouse con codigo " + warehouseCode);
    }
}
